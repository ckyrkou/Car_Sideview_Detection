A database of 948 sideview cars and 3122 negative template images in pgm format. The images are 40x100 pixel resolution.

Please Cite:
Christos Kyrkou, Eftychios Christoforou, Theocharis Theocharides, Christos Panayiotou, Marios Polycarpou, "A Camera Uncertainty Model for Collaborative Visual Sensor Network Applications",  9th International Conference on Distributed Smart Cameras (ICDSC'15), pp. 86-91, 2015.


Copyright 2016
Christos Kyrkou
All rights reserved.

Permission to copy and modify, data,  software, and documentation only for internal research use in your organization is hereby granted, provided that this notice is retained thereon and on all copies. This data and software should not be distributed to anyone outside of your organization without explicit written authorization by the author(s). It should not be used for commercial purposes without specific permission from the authors. The authors also require written authorization by the author(s) to publish results obtained with the data or software and possibly citation of relevant CBCL reference papers.

I make no representation as to the suitability and operability of this data or software for any purpose. It is provided "as is" without express or implied warranty.

Contact: c.kyrkou@gmail.com